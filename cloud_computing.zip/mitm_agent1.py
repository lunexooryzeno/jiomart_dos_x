import os

os.system('mitmdump -s intercept_requests.py -p 8753')
